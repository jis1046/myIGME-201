﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest2Q9
{
    public interface Defense
    {
        void steal();
        void block();
        void rebound();

    }
}

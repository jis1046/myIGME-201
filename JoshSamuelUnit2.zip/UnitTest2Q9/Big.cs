﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest2Q9
{
    public class Big : BasketballPlayer, Offense, Defense
    {
        public void turnover()
        {

        }

        public void shoot()
        {

            System.Console.WriteLine();
            Console.WriteLine("Make a 2pt midrange");
        }

        public void pass()
        {

        }

        public void dribble()
        {

        }
        public void steal()
        {

        }

        public void block()
        {

        }

        public void rebound()
        {

        }
        public override void  play()
        {

        }
        public override void notPlay()
        {

        }
        public override void run()
        {

        }

        public void post()
        {

        }

        public void hook()
        {

        }
        public void dunk()
        {

        }
        public void screen()
        {

        }
    }
}

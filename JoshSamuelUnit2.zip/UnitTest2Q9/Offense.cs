﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest2Q9
{
    public interface Offense
    {
        void turnover();
        void shoot();
        void pass();
        void dribble();
        void rebound();
        void dunk();
        void screen();
    }
}

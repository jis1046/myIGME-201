﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest2Q9
{
    public class Console
    {
        public static void Main(string[] args)
        {
            Big bigMan = new Big();
            Guard pointGuard = new Guard();

            pointGuard.shoot();
            bigMan.shoot();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTest2Q9
{
    public class Guard : BasketballPlayer, Offense, Defense
    {
        public void turnover()
        {

        }

        public void shoot()
        {
            Console.WriteLine("Make a 3 pointer");
            System.Console.WriteLine();
        }

        public  void pass()
        {

        }

        public  void dribble()
        {

        }
        public void steal()
        {

        }

        public void block()
        {

        }

        public void rebound()
        {

        }
        public override void play()
        {

        }
        public override void notPlay()
        {

        }
        public override void run()
        {

        }

        public void crossOver()
        {

        }

        public void betweenLegs()
        {

        }

        public void behindBack()
        {

        }

        public void drive()
        {

        }

        public void dunk()
        {

        }
        public void screen()
        {

        }



    }
}
